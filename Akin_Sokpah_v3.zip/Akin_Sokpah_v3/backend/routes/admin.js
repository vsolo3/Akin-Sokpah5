
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Music = require('../models/Music');
const { verifyToken, verifyAdmin } = require('../middleware/auth');

router.get('/users', verifyToken, verifyAdmin, async (req, res) => {
  const users = await User.find().select('-password');
  res.json(users);
});

router.get('/music', verifyToken, verifyAdmin, async (req, res) => {
  const music = await Music.find().populate('userId', 'username');
  res.json(music);
});

router.delete('/music/:id', verifyToken, verifyAdmin, async (req, res) => {
  await Music.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
