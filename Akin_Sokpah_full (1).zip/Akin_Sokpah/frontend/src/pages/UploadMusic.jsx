import React, { useState } from 'react';
import axios from 'axios';

const UploadMusic = () => {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [genre, setGenre] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [coverImage, setCoverImage] = useState(null);

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('artist', artist);
    formData.append('genre', genre);
    formData.append('description', description);
    formData.append('music', file);
    formData.append('coverImage', coverImage);

    try {
      await axios.post('/api/music/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      window.location.href = '/';
    } catch (err) {
      console.error('Error uploading music', err);
    }
  };

  return (
    <div>
      <h1>Upload Music</h1>
      <input type="text" placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
      <input type="text" placeholder="Artist" onChange={(e) => setArtist(e.target.value)} />
      <input type="text" placeholder="Genre" onChange={(e) => setGenre(e.target.value)} />
      <textarea placeholder="Description" onChange={(e) => setDescription(e.target.value)} />
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <input type="file" onChange={(e) => setCoverImage(e.target.files[0])} />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default UploadMusic;