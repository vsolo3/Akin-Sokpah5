import React from 'react';

const MusicCard = ({ music }) => {
  return (
    <div className="card">
      <img src={music.coverImage} alt="Cover" />
      <h2>{music.title}</h2>
      <p>{music.artist}</p>
      <p>{music.genre}</p>
      <p>{music.description}</p>
      <a href={`/api/music/download/${music._id}`}>Download</a>
    </div>
  );
};

export default MusicCard;