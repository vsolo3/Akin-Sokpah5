import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to Akin Sokpah Music Platform</h1>
    </div>
  );
}

export default App;