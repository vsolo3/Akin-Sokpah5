import React, { useEffect, useState } from 'react';
import axios from 'axios';
import MusicCard from './components/MusicCard';
import MusicPlayer from './components/MusicPlayer';
import Navbar from './components/Navbar';
import './index.css';

const App = () => {
  const [musicList, setMusicList] = useState([]);
  const [selectedTrack, setSelectedTrack] = useState(null);

  useEffect(() => {
    axios.get('/api/music').then(res => {
      setMusicList(res.data);
    });
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {musicList.map(music => (
          <div key={music._id} onClick={() => setSelectedTrack(music)}>
            <MusicCard music={music} />
          </div>
        ))}
      </div>
      {selectedTrack && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
          <MusicPlayer trackUrl={`/api/music/download/${selectedTrack._id}`} title={selectedTrack.title} />
        </div>
      )}
    </div>
  );
};

export default App;