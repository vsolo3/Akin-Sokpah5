import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [music, setMusic] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('/api/admin/users', { headers: { Authorization: `Bearer ${token}` }})
      .then(res => setUsers(res.data));
    axios.get('/api/admin/music', { headers: { Authorization: `Bearer ${token}` }})
      .then(res => setMusic(res.data));
  }, []);

  const deleteTrack = (id) => {
    const token = localStorage.getItem('token');
    axios.delete(`/api/admin/music/${id}`, { headers: { Authorization: `Bearer ${token}` }})
      .then(() => setMusic(prev => prev.filter(m => m._id !== id)));
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
      <h3 className="text-xl font-semibold">Users</h3>
      <ul>{users.map(u => <li key={u._id}>{u.username} {u.isAdmin && '(Admin)'}</li>)}</ul>

      <h3 className="text-xl font-semibold mt-6">Music</h3>
      <ul>
        {music.map(m => (
          <li key={m._id}>
            {m.title} by {m.artist}
            <button onClick={() => deleteTrack(m._id)} className="ml-2 text-red-600">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;