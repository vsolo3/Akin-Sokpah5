import React, { useRef, useState } from 'react';

const MusicPlayer = ({ trackUrl, title }) => {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  const togglePlay = () => {
    if (!playing) {
      audioRef.current.play();
    } else {
      audioRef.current.pause();
    }
    setPlaying(!playing);
  };

  return (
    <div className="p-4 bg-white shadow rounded-lg">
      <h2 className="text-xl font-bold mb-2">{title}</h2>
      <audio ref={audioRef} src={trackUrl} />
      <button onClick={togglePlay} className="px-4 py-2 bg-blue-600 text-white rounded">
        {playing ? 'Pause' : 'Play'}
      </button>
    </div>
  );
};

export default MusicPlayer;