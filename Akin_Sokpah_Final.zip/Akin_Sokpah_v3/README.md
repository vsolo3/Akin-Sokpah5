# Akin Sokpah - Music Platform 🎶

## Features
- Artist uploads (music + cover)
- In-browser audio player
- Responsive Tailwind UI
- Admin dashboard for content management
- Cloudinary integration for file storage
- Secure JWT-based authentication

---

## 🌐 Deployment

### 🚀 Backend: Render

1. Go to https://render.com
2. Create new Web Service
3. Connect your GitHub repo
4. Set build command: `npm install`
5. Start command: `node index.js`
6. Add environment variables from `.env.example`

Make sure to allow CORS for frontend origin (e.g., `https://your-frontend.vercel.app`).

---

### 🌍 Frontend: Vercel

1. Go to https://vercel.com
2. Import your frontend folder (`frontend/`)
3. Set environment variable:

```
VITE_API_URL=https://your-backend.onrender.com
```

4. Update `axios` in frontend code to use:
```js
axios.defaults.baseURL = import.meta.env.VITE_API_URL;
```

---

## 🧪 Local Dev

### Backend
```bash
cd backend
npm install
node index.js
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## 📦 Environment Variables

Use `.env.example` as a template:

```
MONGO_URI=your_mongodb_uri
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

---

## 🙌 Built with MERN stack
- MongoDB + Mongoose
- Express.js
- React + Tailwind CSS
- Node.js