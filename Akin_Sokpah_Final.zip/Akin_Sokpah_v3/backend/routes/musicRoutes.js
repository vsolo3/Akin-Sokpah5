const express = require('express');
const Music = require('../models/Music');
const router = express.Router();
const path = require('path');
const fs = require('fs');

// Route to upload music
router.post('/upload', (req, res) => {
  const { title, artist, genre, description } = req.body;
  const file = req.files.music;
  const coverImage = req.files.coverImage;

  const filePath = path.join(__dirname, '../uploads', file.name);
  const coverImagePath = path.join(__dirname, '../uploads', coverImage.name);

  file.mv(filePath, err => {
    if (err) return res.status(500).send(err);
    coverImage.mv(coverImagePath, err => {
      if (err) return res.status(500).send(err);
    });

    const newMusic = new Music({
      title,
      artist,
      genre,
      description,
      fileUrl: filePath,
      coverImage: coverImagePath
    });

    newMusic.save()
      .then(() => res.status(201).send('Music uploaded successfully'))
      .catch(err => res.status(500).send(err));
  });
});

// Route to get all music
router.get('/', async (req, res) => {
  try {
    const music = await Music.find();
    res.json(music);
  } catch (err) {
    res.status(500).send(err);
  }
});

// Route to download music file
router.get('/download/:id', async (req, res) => {
  try {
    const music = await Music.findById(req.params.id);
    res.download(music.fileUrl);
  } catch (err) {
    res.status(500).send(err);
  }
});

module.exports = router;