
const express = require('express');
const multer = require('multer');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const cloudinary = require('cloudinary').v2;
const Music = require('../models/Music');
const { verifyToken } = require('../middleware/auth');
const router = express.Router();

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: async (req, file) => {
    return {
      folder: 'music-platform',
      resource_type: file.mimetype.startsWith('audio/') ? 'video' : 'image',
      public_id: file.originalname.split('.')[0],
    };
  },
});

const upload = multer({ storage });

router.post('/', verifyToken, upload.fields([{ name: 'music' }, { name: 'cover' }]), async (req, res) => {
  try {
    const music = new Music({
      title: req.body.title,
      artist: req.body.artist,
      musicUrl: req.files['music'][0].path,
      coverUrl: req.files['cover'][0].path,
      userId: req.user.id,
    });
    await music.save();
    res.json(music);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
